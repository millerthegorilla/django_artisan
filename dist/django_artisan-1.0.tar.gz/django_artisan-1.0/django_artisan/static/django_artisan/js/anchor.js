$(document).ready(function(){
	window.location = '#comment'
});